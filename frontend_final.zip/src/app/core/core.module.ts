import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CoreRoutingModule } from './core-routing.module';
import { NavbarComponent } from './components/layout/navbar/navbar.component';
import { LandingComponent } from './components/layout/landing/landing.component';
import { FooterComponent } from './components/layout/footer/footer.component';
import { httpInterceptorProviders } from './interceptors';
import { AlertComponent } from './components/alert/alert.component';
import { AlertserviceService } from './services/alertservice.service';

@NgModule({
  declarations: [
    NavbarComponent,
    LandingComponent,
    FooterComponent,
    AlertComponent,
  ],
  imports: [CommonModule, CoreRoutingModule],
  providers: [httpInterceptorProviders, AlertserviceService],
  exports: [NavbarComponent, AlertComponent, LandingComponent, FooterComponent],
})
export class CoreModule {}
