export class Alert {
  alertType: string;
  message: string;
  duration?: number;
}
