import { Component, OnInit } from '@angular/core';
import { Alert } from '../../models/alert';
import { AlertserviceService } from '../../services/alertservice.service';

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.css'],
})
export class AlertComponent implements OnInit {
  alerts: Array<Alert> = [];
  constructor(private alertService: AlertserviceService) {
    this.alertService.alerts.subscribe({
      next: (alerts) => {
        this.alerts = [...alerts];
      },
    });
  }

  ngOnInit(): void {}
}
