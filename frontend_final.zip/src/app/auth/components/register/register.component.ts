import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertserviceService } from 'src/app/core/services/alertservice.service';
import { Register } from '../../models/register';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  register: Register = new Register();
  message = '';
  constructor(
    private authService: AuthService,
    private alertservice: AlertserviceService,
    private router: Router
  ) {}

  registerSubmit() {
    console.log(JSON.stringify(this.register));

    const newUser: any = {
      username: this.register.username,
      email: this.register.email,
      password: this.register.password,
    };
    // Here in subscribe we have two things success and failure part (sucess is then part and failure is catch part according to axios)
    this.authService.registerUser(newUser).subscribe(
      (res) => {
        console.log('User registered successfully');
        this.router.navigate(['/auth/login']);
        this.alertservice.setAlert({
          alertType: 'success',
          message: 'User registered successfully',
        });
      },
      (err) => {
        if (newUser.email == null) {
          this.alertservice.setAlert({
            alertType: 'danger',
            message: 'email should not be null',
          });
        }
      }
    );
  }
  ngOnInit(): void {}
}
