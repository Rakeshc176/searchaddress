import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Login } from '../../models/login';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  login: Login = new Login();

  constructor(private authService: AuthService, private router: Router) {}

  loginSubmit() {
    console.log(JSON.stringify(this.login));

    const newUser: any = {
      username: this.login.username,
      password: this.login.password,
      errors: this.login.errors,
    };

    // Here in subscribe we have two things success and failure part (sucess is then part and failure is catch part according to axios)
    this.authService.loginUser(newUser).subscribe(
      (res) => {
        localStorage.setItem('token', res.token);
        console.log('User Logged In successfully');
        this.router.navigate(['/dashboard']);
        console.log(JSON.stringify(res)); //if login->success --->generates a token=>prints token
        //to store the token
      },
      (err) => {}
    );
  }

  ngOnInit(): void {}
}
