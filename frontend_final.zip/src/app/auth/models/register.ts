export class Register {
  username: string;
  email: string;
  password: string;
  password2: string;
  errors: string[];
}
