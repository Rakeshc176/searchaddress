import { HttpClient, HttpEvent, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AddressService {
  private baseUrl = 'http://localhost:8080';

  private authUrl =
    '/api/security/oauth/token?grant_type=client_credentials&client_id=33OkryzDZsJhPTVDNpi1TTv6wm5aQb6o2br4xAh65xMaaw0JOr8SX-4NG9GFNkiTF3sbHgkxrtFpjxGmgV2hdYAF9h_WzSktZoOBxhjL-Wlk-4idZg_XOQ==&client_secret=lrFxI-iSEg9AL_eHMBaxbyq9Q-J9bM3KfSoiSVPyNjMAJdgQT0LEr6QL-_Upl7n9wIoFPSzYKCTRpoMQgRHtPZNab0TeDs2fXZ3QHYzIdaqRkdA_Xq4ayXHfE1c-vmus';

  private mapToken: string = '';
  private addressUrl = '/api/places/geocode';

  constructor(private httpClient: HttpClient) {
    console.log('from service');
    this.getToken();
  }
  addAddress(data: any): Observable<any> {
    console.log('from address');
    return this.httpClient.post('/api/address/add', data);
  }
  // getAllAddress(): Observable<any> {
  //   return this.httpClient.get('/api/address/all');
  // }
  upload(file: File): Observable<HttpEvent<any>> {
    const formData: FormData = new FormData();

    formData.append('file', file);

    const req = new HttpRequest('POST', `${this.baseUrl}/upload`, formData, {
      reportProgress: true,
      responseType: 'json',
    });

    return this.httpClient.request(req);
  }
  getFiles(): Observable<any> {
    return this.httpClient.get(`${this.baseUrl}/files`);
  }

  getToken() {
    this.httpClient.post(this.authUrl, {}).subscribe((res: any) => {
      console.log(res);
      this.mapToken = res.access_token;
      console.log(this.mapToken);
    });
  }
  getAddress(address: any) {
    const tempUrl = this.addressUrl + '?itemCount=5&address=' + address;
    console.log({ tempUrl });
    return this.httpClient.get(tempUrl, {
      headers: {
        Authorization: 'Bearer ' + this.mapToken,
      },
    });
  }
  saveAddressToDataBase(address) {
    console.log({ AddressGoingToSave: address });
    return this.httpClient.post('/api/address/add', address);
  }
}
