import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './components/dashboard/dashboard.component';

import { httpInterceptorProviders } from '../core/interceptors';

import { HttpClientModule } from '@angular/common/http';
import { AuthService } from '../auth/services/auth.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AddressService } from './services/address.service';
import { UploadFilesComponent } from './components/upload-files/upload-files.component';

@NgModule({
  declarations: [DashboardComponent, UploadFilesComponent],
  providers: [httpInterceptorProviders, AuthService, AddressService],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
  ],
})
export class DashboardModule {}
