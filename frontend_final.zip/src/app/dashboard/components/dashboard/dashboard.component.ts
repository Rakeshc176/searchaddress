import { HttpEventType, HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AddressService } from '../../services/address.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  searchQuery = '';
  addresses: [];
  selectedAddress: any;
  message = '';
  message1 = '';
  myaddressess = [];

  selectedFiles: FileList;
  currentFile: File;
  progress = 0;
  message3 = '';

  fileInfos: Observable<any>;

  constructor(private addressService: AddressService, private router: Router) {}
  onSubmit() {
    this.router.navigate(['/dashboard/add']);
  }
  onSubmit1() {
    this.router.navigate(['/dashboard/upload-file']);
  }

  onChange() {
    if (this.searchQuery.trim() && this.searchQuery.length > 3) {
      //send a request here
      const address = this.searchQuery;
      this.addressService.getAddress(address).subscribe((res: any) => {
        console.log({ res });

        if (res) {
          this.addresses = res.copResults;
        }
      });
    }
  }
  ngOnInit(): void {
    this.fileInfos = this.addressService.getFiles();
  }
  selectAddress(address: any) {
    console.log('selected address', address);
    this.selectedAddress = address;
    this.searchQuery = address.formattedAddress;
    this.addresses = [];
  }
  saveAddress() {
    console.log(this.selectedAddress);
    if (this.selectedAddress != null) {
      this.addressService
        .saveAddressToDataBase(this.selectedAddress)
        .subscribe((res) => {
          console.log({ res });
          console.log('saved..');
          this.searchQuery = ' ';
          this.message = 'saved successfully';
          this.myaddressess.push(this.selectedAddress);
          this.selectedAddress = {};
        });
    } else {
      this.searchQuery = ' ';
      this.message1 = 'invalid address';

      this.selectedAddress = {};
    }
  }
  selectFile(event: any) {
    this.selectedFiles = event.target.files;
  }

  upload() {
    this.progress = 0;

    this.currentFile = this.selectedFiles.item(0);
    this.addressService.upload(this.currentFile).subscribe(
      (event) => {
        if (event.type === HttpEventType.UploadProgress) {
          this.progress = Math.round((100 * event.loaded) / event.total);
          this.router.navigate['/dashboard'];
        } else if (event instanceof HttpResponse) {
          this.message3 = event.body.message;
          this.fileInfos = this.addressService.getFiles();
          this.router.navigate['/dashboard'];
        }
      },
      (err) => {
        this.progress = 0;
        this.message3 = 'Could not upload the file!';
        this.currentFile = undefined;
      }
    );

    this.selectedFiles = undefined;
  }
}
